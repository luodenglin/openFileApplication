//
//  ViewController.m
//  openFileApplication
//
//  Created by Apple on 2018/4/10.
//  Copyright © 2018年 LuoDengLin. All rights reserved.
//

#import "ViewController.h"
#import <QuickLook/QuickLook.h>
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height


@interface ViewController ()<UIDocumentInteractionControllerDelegate,QLPreviewControllerDataSource> {
    /*
     UIDocumentInteractionController是iOS 很早就出来的一个功能。但由于平时很少用到，压根就没有听说过它。而我们忽略的缺是一个功能强大的”文档阅读器”。
     UIDocumentInteractionController主要由两个功能，一个是文件预览，另一个就是调用iPhoneh里第三方相关的app打开文档（注意这里不是根据url scheme 进行识别，而是苹果的自动识别）
     */
    UIDocumentInteractionController *_documentController; //文档交互控制器
}
@property (strong, nonatomic)QLPreviewController *previewController;
@property (copy, nonatomic)NSURL *fileURL; //文件路径
@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.previewController  =  [[QLPreviewController alloc]  init];
    self.previewController.dataSource  = self;
    NSArray *btnTitleArr = @[@"预览",@"调用外部应用打开",@"quick look预览"];
    for (NSInteger i = 0; i<3; i++) {
        
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
        btn.frame = CGRectMake(20, 100+i*100, kScreenWidth-40, 40);
        btn.layer.cornerRadius = 5;
        btn.backgroundColor = [UIColor greenColor];
        [btn setTitle:btnTitleArr[i] forState:UIControlStateNormal];
        [self.view addSubview:btn];
        if (i == 0) {
            [btn addTarget:self action:@selector(previewClick:) forControlEvents:UIControlEventTouchUpInside];
        }
        else if(i==1) {
            [btn addTarget:self action:@selector(openClick:) forControlEvents:UIControlEventTouchUpInside];
        }else{
            [btn addTarget:self action:@selector(quicklook:) forControlEvents:UIControlEventTouchUpInside];
        }
        
    }
    
    
    
}

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)controller {
    
    //注意：此处要求的控制器，必须是它的页面view，已经显示在window之上了
    return self;
}

//预览
- (void)previewClick:(UIButton *)btn {
    //初始化文档交互
    //准备文档的Url
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"180313C0001_2018-03-22 17_29_41.pdf" withExtension:nil];
    
    _documentController = [UIDocumentInteractionController interactionControllerWithURL:url];
    [_documentController setDelegate:self];
    
    //当前APP打开  需实现协议方法才可以完成预览功能
    [_documentController presentPreviewAnimated:YES];
    
}

//第三方打开 手机中安装有可以打开此格式的软件都可以打开
- (void)openClick:(UIButton *)btn {
    
    //初始化文档交互
    //准备文档的Url
    NSURL *url = [[NSBundle mainBundle] URLForResource:@"180313C0001_2018-03-22 17_29_41.pdf" withExtension:nil];
    _documentController = [UIDocumentInteractionController interactionControllerWithURL:url];
    [_documentController setDelegate:self];
    
    [_documentController presentOpenInMenuFromRect:btn.frame inView:self.view animated:YES];
    
}

- (void)quicklook:(UIButton *)btn{
    [self presentViewController:self.previewController animated:YES completion:nil];
    //刷新界面,如果不刷新的话，不重新走一遍代理方法，返回的url还是上一次的url
    [self.previewController refreshCurrentPreviewItem];
}
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)controller{
    
    return 1;
}
- (id <QLPreviewItem>)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index{
    
    
    return [NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"180313C0001_2018-03-22 17_29_41.pdf" ofType:nil]];
    
}
@end
