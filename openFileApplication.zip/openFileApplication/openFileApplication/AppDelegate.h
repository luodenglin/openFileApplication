//
//  AppDelegate.h
//  openFileApplication
//
//  Created by Apple on 2018/4/10.
//  Copyright © 2018年 LuoDengLin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

